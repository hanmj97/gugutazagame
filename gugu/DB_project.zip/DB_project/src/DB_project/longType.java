package DB_project;

import java.awt.EventQueue;
import java.awt.Label;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import java.awt.Font;


public class longType extends JFrame implements KeyListener, ActionListener {

	private JPanel contentPane;
	private Label label[] = new Label[10000];
	private JLabel AccurLabel;
	private JLabel TypingLabel;
	private JLabel timeLabel;
	private JButton back;
	private JTextPane textPane;
	private JPanel ShortText;
	private int Accur = 0;
	private int Typing = 0;
	Sansung_main main;
	private JTextArea textArea;
	long nStart = System.currentTimeMillis();
	private JTextField InputText;
	private JButton Start;
	private String Nickname;
	
	private String[] tmp = {
			"1. ���ع��� ��λ��� ������ �⵵��" ,
			"�ϴ����� �����ϻ� �츮���� ����" ,
			"����ȭ ��õ�� ȭ�� ����" ,
			"���� ��� �������� ���� �����ϼ�",
			"2. ���� ���� �� �ҳ��� ö���� �θ� ��",
			"�ٶ� ���� �Һ����� �츮 ����ϼ�",
			"����ȭ ��õ�� ȭ�� ����",
			"���� ��� �������� ���� �����ϼ�",
			"3. ���� �ϴ� ��Ȱ�ѵ� ���� ���� ����",
			"���� ���� �츮 ���� �����ܽ��ϼ�",
			"����ȭ ��õ�� ȭ�� ����",
			"���� ��� �������� ���� �����ϼ�",
			"4. �� ���� �� ������ �漺�� ���Ͽ�",
			"���ο쳪 ��ſ쳪 ���� ����ϼ�",
			"����ȭ ��õ�� ȭ�� ����",
			"���� ��� �������� ���� �����ϼ�"
	};
	
	/**
	 * Create the frame.
	 * @param nick 
	 */
	public longType(String nick) {
		Nickname = nick;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1280, 720);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ShortText = new JPanel();
		ShortText.setBounds(0, 0, 990, 620);
		contentPane.add(ShortText);
		ShortText.setLayout(null);
		
		textPane = new JTextPane();
		textPane.setBounds(5, 5, 985, 615);
		ShortText.add(textPane);
		
		textArea = new JTextArea();
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 25));
		textArea.setBounds(5, 5, 985, 615);
		ShortText.add(textArea);
		
		AccurLabel = new JLabel(" ��Ȯ�� : " + Accur + "%");
		AccurLabel.setBounds(1000, 10, 100, 50);
		contentPane.add(AccurLabel);
		
		back = new JButton("Back");
		back.setBounds(1000, 630, 270, 50);
		contentPane.add(back);
		
		TypingLabel = new JLabel("Ÿ�� : " + Typing + "Ÿ/��");
		TypingLabel.setBounds(1000, 70, 110, 50);
		contentPane.add(TypingLabel);
		
		timeLabel = new JLabel("����ð� : 00 : 00");
		timeLabel.setBounds(1000, 130, 110, 50);
		contentPane.add(timeLabel);
		
		Start = new JButton("Start");
		Start.setBounds(1000, 570, 270, 50);
		contentPane.add(Start);
		
		InputText = new JTextField();
		InputText.setBounds(0, 630, 990, 51);
		contentPane.add(InputText);
		InputText.setColumns(10);
		
		setVisible(true);
		
		Start.addActionListener(this);
		InputText.addKeyListener(this);
	}


	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		/*if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			if (!InputText.getText().equals("")) {
				String inText = InputText.getText().toString();
				for (int i = 0; i <= Tmp[nindex].length(); i++) {
					
				}
			}
		}*/
		if(e.getKeyCode() == KeyEvent.VK_SPACE || e.getKeyCode() == KeyEvent.VK_NUMPAD0 ||e.getKeyCode() == KeyEvent.VK_NUMPAD1 || e.getKeyCode() == KeyEvent.VK_NUMPAD2
				|| e.getKeyCode() == KeyEvent.VK_NUMPAD3 || e.getKeyCode() == KeyEvent.VK_NUMPAD4 || e.getKeyCode() == KeyEvent.VK_NUMPAD5 || e.getKeyCode() == KeyEvent.VK_NUMPAD6
				|| e.getKeyCode() == KeyEvent.VK_NUMPAD7 || e.getKeyCode() == KeyEvent.VK_NUMPAD8 || e.getKeyCode() == KeyEvent.VK_NUMPAD9 || e.getKeyCode() == KeyEvent.VK_MULTIPLY
				|| e.getKeyCode() == KeyEvent.VK_ADD || e.getKeyCode() == KeyEvent.VK_SUBTRACT || e.getKeyCode() == KeyEvent.VK_DECIMAL || e.getKeyCode() == KeyEvent.VK_DIVIDE
				|| e.getKeyCode() == KeyEvent.VK_0|| e.getKeyCode() == KeyEvent.VK_1|| e.getKeyCode() == KeyEvent.VK_2|| e.getKeyCode() == KeyEvent.VK_3|| e.getKeyCode() == KeyEvent.VK_4
				|| e.getKeyCode() == KeyEvent.VK_5|| e.getKeyCode() == KeyEvent.VK_6|| e.getKeyCode() == KeyEvent.VK_7|| e.getKeyCode() == KeyEvent.VK_8|| e.getKeyCode() == KeyEvent.VK_9
				|| e.getKeyCode() == KeyEvent.VK_Q|| e.getKeyCode() == KeyEvent.VK_W|| e.getKeyCode() == KeyEvent.VK_E|| e.getKeyCode() == KeyEvent.VK_R|| e.getKeyCode() == KeyEvent.VK_T
				|| e.getKeyCode() == KeyEvent.VK_Y|| e.getKeyCode() == KeyEvent.VK_U|| e.getKeyCode() == KeyEvent.VK_I|| e.getKeyCode() == KeyEvent.VK_O|| e.getKeyCode() == KeyEvent.VK_P
				|| e.getKeyCode() == KeyEvent.VK_A|| e.getKeyCode() == KeyEvent.VK_S|| e.getKeyCode() == KeyEvent.VK_D|| e.getKeyCode() == KeyEvent.VK_F|| e.getKeyCode() == KeyEvent.VK_G
				|| e.getKeyCode() == KeyEvent.VK_H|| e.getKeyCode() == KeyEvent.VK_J|| e.getKeyCode() == KeyEvent.VK_K|| e.getKeyCode() == KeyEvent.VK_L|| e.getKeyCode() == KeyEvent.VK_Z
				|| e.getKeyCode() == KeyEvent.VK_X|| e.getKeyCode() == KeyEvent.VK_C|| e.getKeyCode() == KeyEvent.VK_V|| e.getKeyCode() == KeyEvent.VK_B|| e.getKeyCode() == KeyEvent.VK_N
				|| e.getKeyCode() == KeyEvent.VK_M|| e.getKeyCode()== KeyEvent.VK_PERIOD || e.getKeyCode()== KeyEvent.VK_COLON || e.getKeyCode()== KeyEvent.VK_COMMA || e.getKeyCode()== KeyEvent.VK_SLASH
				|| e.getExtendedKeyCode()== '��')
		{
			Typing++;
			
			TypingLabel.setText("Ÿ�� : " + Typing/((System.currentTimeMillis() - nStart)*1.0D/1000/60)  +"Ÿ/��");
		}
		
	}

	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(Start.getText() == "Start") {
			
			int index = 0;
			
			double Dmin = 0.0;
			long nStart = System.currentTimeMillis();
			String sho ;
			
			
			
		
		
			for(int i = 0; i<16; i++) {
			textArea.append(tmp[i]);
			textArea.append("\n");
			}
			Start.setEnabled(false);
			new shortTime().start();
		}
		if(back.getText() == "Back") {
			
		}
	}
	
	class shortTime extends Thread
	{
		int time = 0;
		int bun = 0;
		public void run()
		{
			while(true)
			{
				try {
					showTime();
					sleep(1000);
				} catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		private void showTime() {
			
			time ++;
			if(time == 60)
			{
				bun++;
				time = 0;
			}
			timeLabel.setText("����ð� : " + bun+ " : " + time);
			
		}
	}
}


